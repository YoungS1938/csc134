// CSC 134
// M3T1_Young
// Seth Young
// 02-05-2019

#include <iostream>

using namespace std;

int main()
{
    int grade;  // individual test score
    int numTests;  // number of total tests
    int average; // average grade
    int total=0;  // accumulator


    // ask user for number of tests to average
    cout<<"How many tests to average? ";
    cin>>numTests;

    for(int count=1; count<=numTests; count++) {
        // within loop, ask for a test grade
        cout<<"Grade for test? ";
        cin>>grade;
        // add it to the total
        total=total + grade;
    }

    cout<<"Total = "<<total<<endl;

    // find the average by dividing total by number of tests
    average = total / numTests;
    cout<<"Your average is "<<average<<"."<<endl;

    //int grade;  // individual test score
   // int numTests;  // number of total tests
   // int average; // average grade
   // int total=0;  // accumulator
   total=0;
   int currentTests = 1;
   cout<<"How many tests are you averaging? ";
   cin>>numTests;

   while (currentTests<=numTests)
   {
 // within loop, ask for a test grade
        cout<<"Grade for test? ";
        cin>>grade;
        // add it to the total
        total=total + grade;
       currentTests++;
   }

   cout<<"Total = "<<total<<endl;

    return 0;
}
