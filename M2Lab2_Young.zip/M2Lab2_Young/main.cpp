// CSC 124
// M2Lab2_Young
// Seth Young
// 01-24-2019

#include <iostream>

using namespace std;

int main()
{ float numberGrade = 0;
  char letterGrade;
  //set numerical grade
  cout << "Please enter the grade for conversion." << endl;
  cin >> numberGrade;
  //convert numerical grade to letter grade
  if (numberGrade>89.5)
  {
      letterGrade = 'A';
  } else
  if (numberGrade>79.5)
  {
      letterGrade = 'B';
  } else
  if (numberGrade>69.5)
  {
      letterGrade = 'C';
  } else
  if (numberGrade>59.5)
  {
      letterGrade = 'D';
  } else
   {
       letterGrade = 'F';
   }
   cout << "The numerical grade entered is: " << numberGrade << endl;
   cout << "The corresponding letter grade is: " << letterGrade << endl;
    return 0;
}
