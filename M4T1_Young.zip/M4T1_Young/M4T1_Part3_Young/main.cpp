/*
CSC 134
M4T1_Part3_Young
Seth Young
02-19-2019
*/

#include <iostream>
#include "sharealike.h"

using namespace std;

int main()
{
    DoubleCheeseburgers = 20;
    EatAtJoes();
    return 0;
}
