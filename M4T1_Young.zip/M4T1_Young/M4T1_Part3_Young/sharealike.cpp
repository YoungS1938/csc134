#include <iostream>
#include "sharealike.h"

using namespace std;

int DoubleCheeseburgers;

void EatAtJoes() {
cout<<"How many cheeseburgers today?"<<endl;
cout<< DoubleCheeseburgers<<endl;
}
