// CSC 134
// M1T1_Part2_Young
// Seth Young
// 02-19-2019

#include <iostream>
#include "safestuff.h"

using namespace std;


int main()
{
   cout<<"Surprise, surprise!"<<endl;
   cout<<"The combination is (once again)"<<endl;
   cout<<SafeCracker(12)<<endl;
    return 0;
}
