#include <iostream>

using namespace std;

string SafeCracker(int SafeID)
{
    return "13-26-16";
}
