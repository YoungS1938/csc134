// CSC 134
// M4T1_Part1_Young
// Seth Young
// 02-19-2019

#include <iostream>

using namespace std;

void BigDog(int KibblesCount);


int main()
{
    BigDog(3);
    return 0;
}
