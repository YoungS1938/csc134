// CSC 134
// M2Lab3_Young
// Seth Young
// 01-31-2019

#include <iostream>

using namespace std;

int main()
{
    /*
    This program will calculate letter grades given a number grade.
    Additions:
    - enter 3 grades each run
    - re-enter invalid grades
    */

   float numberGrade = 0;
   char letterGrade;
   bool isValid = false;
   int testNum;
  cout<<"Grade Entry Program"<<endl;

  //user will enter three test grades
  for (int testNum=1; testNum <4; testNum++)
  {
        cout<<"Enter a grade for test #"<<testNum<<endl;
        isValid=false;
      //ask the user for a numerical grade.
      //must be > 0 and no greater than 100

       while (isValid ==false)
      {
        cout << "Please enter the grade for conversion." << endl;
        cin >> numberGrade;
        if (numberGrade >0 && numberGrade <= 100) {
            isValid = true;
        } else { cout<< "Invalid Number, try again."<<endl; }
      }

      //convert numerical grade to letter grade.
      if (numberGrade>89.5)
      {
          letterGrade = 'A';
      } else
      if (numberGrade>79.5)
      {
          letterGrade = 'B';
      } else
      if (numberGrade>69.5)
      {
          letterGrade = 'C';
      } else
      if (numberGrade>59.5)
      {
          letterGrade = 'D';
      } else
       {
           letterGrade = 'F';
       }

       //return the numerical and letter grade to the user.
       cout << "The numerical grade entered is: " << numberGrade << endl;
       cout << "The corresponding letter grade is: " << letterGrade << endl;

    }
    return 0;
}
