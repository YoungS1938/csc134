// CSC134
// M2HW1_Young
// Seth Young
// 01-29-2019

#include <iostream>

using namespace std;

int main()
{
    // 1. Write a program that asks the user for the length and width of a rectangle and tells them its area.
    double l=0;
    double w=0;
    double a=0;
    cout<<"What is the length? ";
    cin>> l;
    cout<<"What is the width? ";
    cin>> w;
    a= l*w;
    cout<<"The area is "<< a<<"."<<endl;

    // 2. Write a program that takes a Celsius temperature and converts it to Fahrenheit.
    double c=0;
    double f=0;
    cout<<"What is the temperature in Celsius? ";
    cin>>c;
    f= (c * 1.8) + 32;

    cout<<"The temperature in Fahrenheit is "<< f<< "."<<endl;

    // 4. Write a program that asks the user for three numerical test grades. Find the average of the grades and then tell them their final letter grade.
    double g1=0;
    double g2=0;
    double g3=0;
    double average=0;
    cout<<"What is your first grade? ";
    cin>>g1;
    cout<<"What is your second grade? ";
    cin>>g2;
    cout<<"What is your last grade? ";
    cin>>g3;
    average = (g1 + g2 + g3) / 3;
    cout<<"Your average is "<< average<<"."<<endl;
    // 3. Modify your movie database program from the lab to ask the user to enter in information about two different movies.


    return 0;
}
